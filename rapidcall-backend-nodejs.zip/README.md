# RapidCall - Production Node.js & Express Backend
**Entity**: R2P Global Resources Nigeria  
**Platform**: RapidCall Nigerian Business Directory & Instant Response Network

---

## 📦 What is inside this backend package?

This standalone backend provides everything needed to run RapidCall in production or local environments:
- **Express.js Server** with modular routing for Businesses, Messaging, Paystack, and Admin.
- **Relational Database DDL (`schema.sql`)** for PostgreSQL (compatible with Neon, Supabase, Cloud SQL, AWS RDS).
- **Automated Migration Runner (`npm run migrate`)**.
- **Paystack Recurring Subscription Engine (₦8,000/month)** with Webhook security (`HMAC-SHA512`).
- **Instant Response Loop**: Rapid messaging, unread badges, and post-service 5-star customer ratings.
- **In-Memory Fallback Store**: Out of the box, it starts and runs immediately even before PostgreSQL is provisioned!

---

## 🚀 Quick Start (Local Setup)

### 1. Extract & Install Dependencies
```bash
# Unzip the downloaded file
unzip rapidcall-backend-nodejs.zip
cd rapidcall-backend

# Install node packages
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Update the following keys in `.env`:
- `DATABASE_URL`: Your PostgreSQL connection string.
- `PAYSTACK_SECRET_KEY`: Your Paystack secret key from https://dashboard.paystack.com
- `GOOGLE_MAPS_API_KEY`: Google Maps Platform API key.

### 3. Run Database Migrations (PostgreSQL)
```bash
npm run migrate
```

### 4. Start the Server
```bash
# Start production server
npm start

# Or with live auto-reload during development
npm run dev
```

The server will be running at `http://localhost:5000`. Test health:
```bash
curl http://localhost:5000/api/health
```

---

## 📡 API Endpoints Overview

| Method | Route | Description |
|---|---|---|
| `GET` | `/api/health` | Health check, DB connection state, and version |
| `GET` | `/api/businesses` | List verified businesses (filters: `category`, `city`, `search`) |
| `POST` | `/api/businesses` | Register new business with 30-Day trial |
| `GET` | `/api/businesses/:id` | Fetch business profile & Google Maps coordinates |
| `GET` | `/api/conversations` | List conversations for user or merchant |
| `POST` | `/api/messages` | Send instant request or chat message |
| `PATCH`| `/api/conversations/:id/resolve` | Mark resolved & trigger 5-star feedback |
| `POST` | `/api/ratings` | Submit 5-star rating and commentary |
| `POST` | `/api/paystack/initialize` | Initialize ₦8,000/month recurring plan |
| `GET`  | `/api/paystack/verify/:reference` | Verify Paystack transaction |
| `POST` | `/api/paystack/webhook` | Paystack webhook receiver |
| `GET`  | `/api/admin/broadcasts` | Administrative intercom broadcasts |
| `POST` | `/api/admin/broadcasts` | Dispatch announcement to merchants |
| `GET`  | `/api/admin/payout-config` | View Access Bank payout configuration |

---

## 🚢 Deploying to Production

### Deploy to Render / Railway / Heroku
1. Push this folder to a GitHub repository.
2. Link the repository to **Render** or **Railway**.
3. Set Build Command to `npm install` and Start Command to `node src/server.js`.
4. Add the environment variables from your `.env` in the dashboard.
5. In Paystack Settings -> Webhooks, set your webhook URL to:  
   `https://your-backend-domain.com/api/paystack/webhook`

---
© 2026 R2P Global Resources. All rights reserved.
