const express = require('express');
const router = express.Router();

let conversationsMemStore = [
  {
    id: 'conv-1',
    businessId: 'biz-1',
    businessName: 'Apex International Academy',
    customerId: 'user-cust-1',
    customerName: 'Tunde Adeyemi',
    customerPhone: '+234 814 987 6543',
    lastMessage: 'Good day, please do you still have slot for Grade 4 entrance exam this Saturday?',
    lastMessageAt: new Date().toISOString(),
    unreadCount: 1,
    isUrgent: true,
    requestType: 'Instant Service Call',
    status: 'active'
  }
];

let messagesMemStore = [
  {
    id: 'msg-1',
    conversationId: 'conv-1',
    businessId: 'biz-1',
    senderId: 'user-cust-1',
    senderName: 'Tunde Adeyemi',
    senderRole: 'customer',
    recipientId: 'user-biz-1',
    content: 'Good day! I am relocating my family to Lekki Phase 1 and need urgent admission details.',
    requestType: 'General Inquiry',
    isUrgent: true,
    isRead: true,
    createdAt: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: 'msg-2',
    conversationId: 'conv-1',
    businessId: 'biz-1',
    senderId: 'user-biz-1',
    senderName: 'Chinedu Okeke (Principal)',
    senderRole: 'business_owner',
    recipientId: 'user-cust-1',
    content: 'Welcome Mr. Adeyemi! We are delighted to assist. Which grade level is your ward entering?',
    isRead: true,
    createdAt: new Date(Date.now() - 1800000).toISOString()
  },
  {
    id: 'msg-3',
    conversationId: 'conv-1',
    businessId: 'biz-1',
    senderId: 'user-cust-1',
    senderName: 'Tunde Adeyemi',
    senderRole: 'customer',
    recipientId: 'user-biz-1',
    content: 'Good day, please do you still have slot for Grade 4 entrance exam this Saturday?',
    requestType: 'Instant Service Call',
    isUrgent: true,
    isRead: false,
    createdAt: new Date().toISOString()
  }
];

let ratingsMemStore = [
  {
    id: 'rate-1',
    businessId: 'biz-1',
    customerId: 'user-cust-2',
    customerName: 'Ngozi Eze',
    serviceCategory: 'Education/Schools',
    starRating: 5,
    comment: 'Super fast response within 2 minutes of sending instant request. Excellent admission tour!',
    createdAt: new Date().toISOString()
  }
];

// GET /api/conversations
router.get('/conversations', (req, res) => {
  const { businessId, customerId } = req.query;
  let list = [...conversationsMemStore];
  if (businessId) list = list.filter(c => c.businessId === businessId);
  if (customerId) list = list.filter(c => c.customerId === customerId);
  res.json({ conversations: list });
});

// GET /api/conversations/:id/messages
router.get('/conversations/:id/messages', (req, res) => {
  const msgs = messagesMemStore.filter(m => m.conversationId === req.params.id);
  res.json({ messages: msgs });
});

// POST /api/messages (Send instant request or chat message)
router.post('/messages', (req, res) => {
  const {
    conversationId,
    businessId,
    businessName,
    senderId,
    senderName,
    senderRole,
    content,
    requestType,
    isUrgent,
    customerPhone
  } = req.body;

  if (!content || !senderName) {
    return res.status(400).json({ error: 'Message content and sender name are required.' });
  }

  let targetConvId = conversationId;

  // If new conversation initiated by customer instant request
  if (!targetConvId) {
    targetConvId = `conv-${Date.now()}`;
    const newConv = {
      id: targetConvId,
      businessId: businessId || 'biz-1',
      businessName: businessName || 'RapidCall Merchant',
      customerId: senderId || 'current-customer',
      customerName: senderName,
      customerPhone: customerPhone || '+234 800 000 0000',
      lastMessage: content,
      lastMessageAt: new Date().toISOString(),
      unreadCount: 1, // Triggers merchant notification badge!
      isUrgent: Boolean(isUrgent),
      requestType: requestType || 'General Inquiry',
      status: 'active'
    };
    conversationsMemStore.unshift(newConv);
  } else {
    // Update existing conversation
    const convIndex = conversationsMemStore.findIndex(c => c.id === targetConvId);
    if (convIndex !== -1) {
      conversationsMemStore[convIndex].lastMessage = content;
      conversationsMemStore[convIndex].lastMessageAt = new Date().toISOString();
      if (senderRole === 'customer') {
        conversationsMemStore[convIndex].unreadCount = (conversationsMemStore[convIndex].unreadCount || 0) + 1;
      } else {
        conversationsMemStore[convIndex].unreadCount = 0;
      }
    }
  }

  const newMsg = {
    id: `msg-${Date.now()}`,
    conversationId: targetConvId,
    businessId,
    senderId: senderId || 'user',
    senderName,
    senderRole: senderRole || 'customer',
    content,
    requestType: requestType || 'General Inquiry',
    isUrgent: Boolean(isUrgent),
    isRead: senderRole === 'business_owner',
    createdAt: new Date().toISOString()
  };

  messagesMemStore.push(newMsg);

  res.status(201).json({
    message: 'Message delivered successfully',
    data: newMsg,
    conversationId: targetConvId
  });
});

// PATCH /api/conversations/:id/resolve
router.patch('/conversations/:id/resolve', (req, res) => {
  const convIndex = conversationsMemStore.findIndex(c => c.id === req.params.id);
  if (convIndex === -1) {
    return res.status(404).json({ error: 'Conversation not found' });
  }

  conversationsMemStore[convIndex].status = 'resolved';
  res.json({
    message: 'Conversation marked resolved. Triggering 5-star metric feedback modal.',
    conversation: conversationsMemStore[convIndex]
  });
});

// POST /api/ratings
router.post('/ratings', (req, res) => {
  const { businessId, customerId, customerName, starRating, comment } = req.body;
  if (!businessId || !starRating) {
    return res.status(400).json({ error: 'businessId and starRating (1-5) are required.' });
  }

  const newRating = {
    id: `rate-${Date.now()}`,
    businessId,
    customerId: customerId || 'cust-anonymous',
    customerName: customerName || 'Verified Customer',
    starRating: Number(starRating),
    comment: comment || '',
    createdAt: new Date().toISOString()
  };

  ratingsMemStore.unshift(newRating);
  res.status(201).json({
    message: 'Rating submitted successfully',
    rating: newRating
  });
});

// GET /api/ratings
router.get('/ratings', (req, res) => {
  const { businessId } = req.query;
  let results = ratingsMemStore;
  if (businessId) {
    results = results.filter(r => r.businessId === businessId);
  }
  res.json({ ratings: results });
});

module.exports = router;
