const express = require('express');
const router = express.Router();
const { pool } = require('../db/db');

// In-memory store fallback for instant development testing
let businessesMemStore = [
  {
    id: 'biz-1',
    ownerId: 'user-biz-1',
    ownerName: 'Chinedu Okeke',
    businessName: 'Apex International Academy',
    category: 'Education/Schools',
    address: 'Plot 14 Admiralty Way, Lekki Phase 1',
    city: 'Lekki',
    state: 'Lagos',
    latitude: 6.4474,
    longitude: 3.4723,
    isLocationVerified: true,
    primaryPhone: '+234 803 214 9876',
    secondaryPhone: '+234 809 111 2233',
    officialEmail: 'admissions@apexacademy.ng',
    portfolioImages: [
      'https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1509062522246-3755977927d7?w=600&auto=format&fit=crop&q=80'
    ],
    ratingAverage: 4.9,
    totalReviews: 48,
    isSubscriptionActive: true,
    registrationDate: '2026-08-20T09:00:00Z',
    trialDaysRemaining: 3,
    simulatedDay: 28,
    description: 'Premier British & Nigerian curriculum school fostering academic excellence and technological literacy.'
  },
  {
    id: 'biz-2',
    ownerId: 'user-biz-2',
    ownerName: 'Amina Bello',
    businessName: 'Bukka Hut & Grill Lounge',
    category: 'Restaurant',
    address: '22 Awolowo Road, Ikoyi',
    city: 'Ikoyi',
    state: 'Lagos',
    latitude: 6.4521,
    longitude: 3.4356,
    isLocationVerified: true,
    primaryPhone: '+234 802 345 6789',
    secondaryPhone: '+234 818 444 5566',
    officialEmail: 'orders@bukkahutvi.com',
    portfolioImages: [
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&auto=format&fit=crop&q=80'
    ],
    ratingAverage: 4.7,
    totalReviews: 112,
    isSubscriptionActive: false, // Day 31 Paywall Triggered
    registrationDate: '2026-08-10T12:00:00Z',
    trialDaysRemaining: 0,
    simulatedDay: 31,
    description: 'Authentic Nigerian native cuisine, grilled catfish, jollof rice, and corporate outdoor catering.'
  }
];

// GET /api/businesses (List all with filters)
router.get('/', async (req, res) => {
  const { category, city, search } = req.query;

  let results = [...businessesMemStore];

  if (category && category !== 'All') {
    results = results.filter(b => b.category.toLowerCase() === category.toLowerCase());
  }

  if (city && city !== 'All Cities') {
    results = results.filter(b => b.city.toLowerCase().includes(city.toLowerCase()) || b.state.toLowerCase().includes(city.toLowerCase()));
  }

  if (search) {
    const q = search.toLowerCase();
    results = results.filter(b => 
      b.businessName.toLowerCase().includes(q) ||
      b.address.toLowerCase().includes(q) ||
      (b.description && b.description.toLowerCase().includes(q))
    );
  }

  res.json({
    count: results.length,
    businesses: results
  });
});

// GET /api/businesses/:id
router.get('/:id', (req, res) => {
  const biz = businessesMemStore.find(b => b.id === req.params.id);
  if (!biz) {
    return res.status(404).json({ error: 'Business not found' });
  }
  res.json(biz);
});

// POST /api/businesses (Register business)
router.post('/', (req, res) => {
  const {
    businessName,
    category,
    address,
    city,
    state,
    latitude,
    longitude,
    primaryPhone,
    secondaryPhone,
    officialEmail,
    portfolioImages,
    description
  } = req.body;

  if (!businessName || !category || !address || !primaryPhone || !officialEmail) {
    return res.status(400).json({ error: 'Missing required onboarding parameters.' });
  }

  const newBiz = {
    id: `biz-${Date.now()}`,
    ownerId: `user-biz-${Date.now()}`,
    ownerName: 'Registered Merchant',
    businessName,
    category,
    address,
    city: city || 'Lagos',
    state: state || 'Lagos',
    latitude: Number(latitude) || 6.5244,
    longitude: Number(longitude) || 3.3792,
    isLocationVerified: Boolean(latitude && longitude),
    primaryPhone,
    secondaryPhone: secondaryPhone || '',
    officialEmail,
    portfolioImages: Array.isArray(portfolioImages) && portfolioImages.length > 0 ? portfolioImages : [
      'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&auto=format&fit=crop&q=80'
    ],
    ratingAverage: 5.0,
    totalReviews: 0,
    isSubscriptionActive: true,
    registrationDate: new Date().toISOString(),
    trialDaysRemaining: 30,
    simulatedDay: 1,
    description: description || 'Verified merchant registered on RapidCall by R2P Global Resources.'
  };

  businessesMemStore.unshift(newBiz);

  res.status(201).json({
    message: 'Business registered successfully with 30-Day complimentary trial!',
    business: newBiz
  });
});

// PUT /api/businesses/:id
router.put('/:id', (req, res) => {
  const index = businessesMemStore.findIndex(b => b.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Business not found' });
  }

  businessesMemStore[index] = {
    ...businessesMemStore[index],
    ...req.body
  };

  res.json({
    message: 'Business updated successfully',
    business: businessesMemStore[index]
  });
});

module.exports = router;
