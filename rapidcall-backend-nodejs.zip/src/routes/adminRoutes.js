const express = require('express');
const router = express.Router();

let broadcastsMemStore = [
  {
    id: 'broadcast-1',
    senderEntity: 'R2P Global Resources',
    title: 'Welcome to RapidCall Nigeria - Merchant Guidelines & Trial Policy',
    content: 'All verified Nigerian merchants receive 30-Day complimentary access. Please verify your Google Map location to maintain verified directory status and prioritize customer dispatch.',
    type: 'rule',
    createdAt: '2026-09-01T10:00:00Z',
    replies: [
      {
        id: 'reply-1',
        businessId: 'biz-1',
        businessName: 'Apex International Academy',
        message: 'Coordinates verified at Lekki Phase 1 gate. Thank you R2P team!',
        createdAt: '2026-09-02T08:15:00Z'
      }
    ]
  },
  {
    id: 'broadcast-2',
    senderEntity: 'R2P Global Resources',
    title: 'Paystack Recurring Billing Integration Now Active',
    content: 'Automated ₦8,000 monthly subscriptions now live via Access Bank PLC settlement. Ensure your billing card is attached before Day 31 to prevent contact shielding.',
    type: 'update',
    createdAt: '2026-09-10T14:30:00Z',
    replies: []
  }
];

let payoutConfigMemStore = {
  bankName: 'Access Bank PLC',
  accountNumber: '0123456789',
  accountName: 'R2P Global Resources Nigeria Ltd',
  currency: 'NGN',
  monthlySubscriptionFeeNaira: 8000,
  settlementSchedule: 'Automated Weekly Friday Payout',
  lastPayoutDate: '2026-09-15T18:00:00Z',
  totalCollectedNaira: 1440000
};

// GET /api/admin/broadcasts
router.get('/broadcasts', (req, res) => {
  res.json({ broadcasts: broadcastsMemStore });
});

// POST /api/admin/broadcasts
router.post('/broadcasts', (req, res) => {
  const { title, content, type = 'update' } = req.body;
  if (!title || !content) {
    return res.status(400).json({ error: 'Title and content are required.' });
  }

  const newBroadcast = {
    id: `broadcast-${Date.now()}`,
    senderEntity: 'R2P Global Resources',
    title,
    content,
    type,
    createdAt: new Date().toISOString(),
    replies: []
  };

  broadcastsMemStore.unshift(newBroadcast);
  res.status(201).json({
    message: 'Broadcast dispatched to all Nigerian merchants',
    broadcast: newBroadcast
  });
});

// POST /api/admin/broadcasts/:id/reply
router.post('/broadcasts/:id/reply', (req, res) => {
  const { businessId, businessName, message } = req.body;
  const broadcast = broadcastsMemStore.find(b => b.id === req.params.id);
  if (!broadcast) {
    return res.status(404).json({ error: 'Broadcast not found' });
  }

  const newReply = {
    id: `reply-${Date.now()}`,
    businessId: businessId || 'biz-user',
    businessName: businessName || 'Verified Merchant',
    message: message || '',
    createdAt: new Date().toISOString()
  };

  if (!broadcast.replies) broadcast.replies = [];
  broadcast.replies.push(newReply);

  res.status(201).json({
    message: 'Reply sent to R2P Administrators',
    reply: newReply
  });
});

// GET /api/admin/payout-config
router.get('/payout-config', (req, res) => {
  res.json(payoutConfigMemStore);
});

// PUT /api/admin/payout-config
router.put('/payout-config', (req, res) => {
  payoutConfigMemStore = {
    ...payoutConfigMemStore,
    ...req.body
  };
  res.json({
    message: 'Admin payout account updated',
    payoutConfig: payoutConfigMemStore
  });
});

module.exports = router;
