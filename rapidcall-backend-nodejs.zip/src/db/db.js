const { Pool } = require('pg');

let pool = null;

if (process.env.DATABASE_URL) {
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
  });
} else {
  // Mock pool interface when no PostgreSQL credentials configured yet
  pool = {
    query: async () => {
      console.warn('[RapidCall DB] No DATABASE_URL provided. Operating in safe in-memory fallback mode.');
      return { rows: [] };
    }
  };
}

async function testDbConnection() {
  if (!process.env.DATABASE_URL) {
    console.log('ℹ️  No DATABASE_URL configured in .env. Falling back to built-in in-memory data store.');
    return false;
  }
  try {
    const res = await pool.query('SELECT NOW()');
    console.log('✅ PostgreSQL database connected successfully at:', res.rows[0].now);
    return true;
  } catch (err) {
    console.error('⚠️  Failed to connect to PostgreSQL database:', err.message);
    console.log('ℹ️  Operating in hybrid in-memory fallback mode.');
    return false;
  }
}

module.exports = { pool, testDbConnection };
