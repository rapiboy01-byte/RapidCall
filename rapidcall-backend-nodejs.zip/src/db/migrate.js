const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { pool } = require('./db');

async function runMigration() {
  if (!process.env.DATABASE_URL) {
    console.error('❌ Error: DATABASE_URL is not set in your .env file.');
    console.log('Please configure a PostgreSQL connection string (e.g. Supabase, Neon, or local).');
    process.exit(1);
  }

  try {
    console.log('🚀 Running RapidCall database migration on PostgreSQL...');
    const schemaSql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await pool.query(schemaSql);
    console.log('✅ RapidCall database tables, indexes, and constraints successfully created!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
    process.exit(1);
  }
}

runMigration();
