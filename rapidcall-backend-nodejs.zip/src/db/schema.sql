-- ========================================================
-- RapidCall Relational Database Schema (PostgreSQL)
-- Entity: R2P Global Resources (Nigeria)
-- Architecture: Multi-tenant directory, real-time messaging,
-- 30-day trial & Paystack subscription billing.
-- ========================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Users Table (Role-based access)
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(64) PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(32) NOT NULL,
    role VARCHAR(32) NOT NULL CHECK (role IN ('customer', 'business_owner', 'admin')),
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Businesses Table
CREATE TABLE IF NOT EXISTS businesses (
    id VARCHAR(64) PRIMARY KEY,
    owner_id VARCHAR(64) REFERENCES users(id) ON DELETE SET NULL,
    owner_name VARCHAR(255) NOT NULL,
    business_name VARCHAR(255) NOT NULL,
    category VARCHAR(64) NOT NULL CHECK (category IN (
        'Retail Stores',
        'Restaurant',
        'Business Centers',
        'Education/Schools',
        'Professional Services',
        'Others'
    )),
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    is_location_verified BOOLEAN DEFAULT FALSE,
    primary_phone VARCHAR(32) NOT NULL,
    secondary_phone VARCHAR(32),
    official_email VARCHAR(255) NOT NULL,
    portfolio_images TEXT[] DEFAULT '{}',
    rating_average NUMERIC(3, 2) DEFAULT 5.00,
    total_reviews INTEGER DEFAULT 0,
    is_subscription_active BOOLEAN DEFAULT TRUE,
    registration_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    trial_end_date TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Subscriptions & Paystack Transactions
CREATE TABLE IF NOT EXISTS subscriptions (
    id VARCHAR(64) PRIMARY KEY,
    business_id VARCHAR(64) NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    plan_code VARCHAR(64) DEFAULT 'PLN_rapidcall_monthly_8k',
    amount_naira INTEGER DEFAULT 8000,
    status VARCHAR(32) NOT NULL CHECK (status IN ('active', 'past_due', 'canceled', 'trialing')),
    trial_start TIMESTAMP WITH TIME ZONE NOT NULL,
    trial_end TIMESTAMP WITH TIME ZONE NOT NULL,
    next_payment_date TIMESTAMP WITH TIME ZONE,
    paystack_customer_code VARCHAR(100),
    paystack_subscription_code VARCHAR(100),
    paystack_auth_token VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Conversations Table
CREATE TABLE IF NOT EXISTS conversations (
    id VARCHAR(64) PRIMARY KEY,
    business_id VARCHAR(64) NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    business_name VARCHAR(255) NOT NULL,
    customer_id VARCHAR(64) REFERENCES users(id) ON DELETE SET NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(32) NOT NULL,
    last_message TEXT,
    last_message_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    unread_count INTEGER DEFAULT 0,
    is_urgent BOOLEAN DEFAULT FALSE,
    request_type VARCHAR(64) DEFAULT 'General Inquiry',
    status VARCHAR(32) DEFAULT 'active' CHECK (status IN ('active', 'resolved')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. Messages Table (Instant Response Loop)
CREATE TABLE IF NOT EXISTS messages (
    id VARCHAR(64) PRIMARY KEY,
    conversation_id VARCHAR(64) NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    business_id VARCHAR(64) REFERENCES businesses(id) ON DELETE CASCADE,
    sender_id VARCHAR(64) NOT NULL,
    sender_name VARCHAR(255) NOT NULL,
    sender_role VARCHAR(32) NOT NULL CHECK (sender_role IN ('customer', 'business_owner', 'admin')),
    recipient_id VARCHAR(64),
    content TEXT NOT NULL,
    request_type VARCHAR(64),
    is_urgent BOOLEAN DEFAULT FALSE,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. Post-Service 5-Star Metric Ratings
CREATE TABLE IF NOT EXISTS ratings (
    id VARCHAR(64) PRIMARY KEY,
    business_id VARCHAR(64) NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    customer_id VARCHAR(64) REFERENCES users(id) ON DELETE SET NULL,
    customer_name VARCHAR(255) NOT NULL,
    service_category VARCHAR(64),
    star_rating SMALLINT NOT NULL CHECK (star_rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Admin Broadcasts & Intercom
CREATE TABLE IF NOT EXISTS admin_broadcasts (
    id VARCHAR(64) PRIMARY KEY,
    sender_entity VARCHAR(100) DEFAULT 'R2P Global Resources',
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    type VARCHAR(32) NOT NULL CHECK (type IN ('update', 'rule', 'warning')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Admin Broadcast Replies
CREATE TABLE IF NOT EXISTS broadcast_replies (
    id VARCHAR(64) PRIMARY KEY,
    broadcast_id VARCHAR(64) NOT NULL REFERENCES admin_broadcasts(id) ON DELETE CASCADE,
    business_id VARCHAR(64) REFERENCES businesses(id) ON DELETE CASCADE,
    business_name VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. Admin Bank Payout Account Config
CREATE TABLE IF NOT EXISTS admin_payout_config (
    id VARCHAR(64) PRIMARY KEY,
    bank_name VARCHAR(100) NOT NULL,
    account_number VARCHAR(32) NOT NULL,
    account_name VARCHAR(255) NOT NULL,
    currency VARCHAR(8) DEFAULT 'NGN',
    monthly_subscription_fee_naira INTEGER DEFAULT 8000,
    settlement_schedule VARCHAR(50) DEFAULT 'Automated Weekly Friday Payout',
    total_collected_naira BIGINT DEFAULT 0,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_businesses_category ON businesses(category);
CREATE INDEX IF NOT EXISTS idx_businesses_city ON businesses(city);
CREATE INDEX IF NOT EXISTS idx_businesses_coords ON businesses(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_conversations_business ON conversations(business_id);
CREATE INDEX IF NOT EXISTS idx_conversations_customer ON conversations(customer_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_unread ON messages(is_read) WHERE is_read = FALSE;
CREATE INDEX IF NOT EXISTS idx_ratings_business ON ratings(business_id);
