/**
 * ============================================================================
 * RapidCall Node.js & Express Production Server
 * Organization: R2P Global Resources Nigeria
 * Features:
 *  - Verified Nigerian Merchant Directory with Categories & Google Maps Coords
 *  - Instant Customer Service Requests & Real-time Bidirectional Messages
 *  - 30-Day Free Trial Engine & Day 31 Paywall Lock
 *  - Paystack Recurring Billing (₦8,000/month) & Webhook Event Processing
 *  - Admin Intercom Broadcaster & Bank Payout Management
 * ============================================================================
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const { pool, testDbConnection } = require('./db/db');

// Import Routes
const businessRoutes = require('./routes/businessRoutes');
const messageRoutes = require('./routes/messageRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Security & Parsing Middleware
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-paystack-signature']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Request Logger
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// Root Health & Metadata Endpoint
app.get('/api/health', async (req, res) => {
  let dbStatus = 'disconnected (using in-memory data store)';
  try {
    if (process.env.DATABASE_URL) {
      await pool.query('SELECT 1');
      dbStatus = 'connected (PostgreSQL active)';
    }
  } catch (err) {
    dbStatus = `error: ${err.message}`;
  }

  res.json({
    status: 'online',
    app: 'RapidCall Backend API',
    organization: 'R2P Global Resources Nigeria',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    database: dbStatus,
    timestamp: new Date().toISOString()
  });
});

// Mount Feature Routes
app.use('/api/businesses', businessRoutes);
app.use('/api', messageRoutes);
app.use('/api/paystack', paymentRoutes);
app.use('/api/admin', adminRoutes);

// Database Schema Exporter
app.get('/api/db/schema', (req, res) => {
  const fs = require('fs');
  const path = require('path');
  const schemaPath = path.join(__dirname, 'db', 'schema.sql');
  if (fs.existsSync(schemaPath)) {
    res.setHeader('Content-Type', 'text/plain');
    return res.sendFile(schemaPath);
  }
  res.json({ message: 'Schema file located in src/db/schema.sql' });
});

// Global 404 Handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    requestedUrl: req.originalUrl
  });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[RapidCall Server Error]', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    timestamp: new Date().toISOString()
  });
});

// Initialize Server
async function start() {
  await testDbConnection();
  app.listen(PORT, '0.0.0.0', () => {
    console.log('====================================================');
    console.log(`🚀 RapidCall Node.js Server listening on port ${PORT}`);
    console.log(`📍 Organization: R2P Global Resources Nigeria`);
    console.log(`🔗 Health Check: http://localhost:${PORT}/api/health`);
    console.log('====================================================');
  });
}

start();

module.exports = app;
